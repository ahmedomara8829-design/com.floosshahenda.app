import 'package:flutter/material.dart';

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  String _money(int minor) {
    final value = minor / 100;
    return '${value.toStringAsFixed(2)} ج.م';
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    return Scaffold(
      appBar: AppBar(
        title: const Text('💰 فلوس شاهندة'),
        centerTitle: true,
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
          children: [
            Text(
              '${now.day.toString().padLeft(2, '0')}/${now.month.toString().padLeft(2, '0')}/${now.year}',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 6),
            Text(
              'أساس التطبيق جاهز — قاعدة البيانات والتقارير ستُربط في المراحل التالية',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodySmall,
            ),
            const SizedBox(height: 20),
            _BalanceCard(value: _money(0)),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(child: _StatCard(title: 'إجمالي الدخل', value: _money(0), icon: Icons.trending_up, color: Colors.green)),
                const SizedBox(width: 12),
                Expanded(child: _StatCard(title: 'المصروفات', value: _money(0), icon: Icons.trending_down, color: Colors.red)),
              ],
            ),
            const SizedBox(height: 12),
            _StatCard(title: 'عدد العمليات', value: '0', icon: Icons.receipt_long, color: Colors.orange),
            const SizedBox(height: 24),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    Icon(Icons.account_balance_wallet_outlined, size: 48, color: Theme.of(context).colorScheme.primary),
                    const SizedBox(height: 10),
                    Text('ابدأ بإضافة أول عملية', style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 6),
                    const Text('سيتم ربط أزرار الدخل والمصروف بقاعدة البيانات في المرحلة التالية.'),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {},
        icon: const Icon(Icons.add),
        label: const Text('عملية جديدة'),
      ),
    );
  }
}

class _BalanceCard extends StatelessWidget {
  const _BalanceCard({required this.value});
  final String value;

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Theme.of(context).colorScheme.primary,
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            const Text('الرصيد الحالي', style: TextStyle(color: Colors.white70)),
            const SizedBox(height: 8),
            Text(value, style: const TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({required this.title, required this.value, required this.icon, required this.color});
  final String title;
  final String value;
  final IconData icon;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            CircleAvatar(backgroundColor: color.withValues(alpha: 0.12), foregroundColor: color, child: Icon(icon)),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title), const SizedBox(height: 4), Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17))])),
          ],
        ),
      ),
    );
  }
}
