import 'package:drift/drift.dart';
import 'package:drift_flutter/drift_flutter.dart';

part 'app_database.g.dart';

class Transactions extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get type => text()();
  IntColumn get amountMinor => integer()();
  TextColumn get description => text().withLength(min: 1, max: 500)();
  TextColumn get category => text().nullable()();
  TextColumn get notes => text().nullable()();
  DateTimeColumn get transactionDate => dateTime()();
  DateTimeColumn get createdAt => dateTime()();
  DateTimeColumn get updatedAt => dateTime()();
  TextColumn get importHash => text().nullable().unique()();
}

@DriftDatabase(tables: [Transactions])
class AppDatabase extends _$AppDatabase {
  AppDatabase() : super(driftDatabase(name: 'floos_shahenda'));

  @override
  int get schemaVersion => 1;

  Future<int> addTransaction({
    required String type,
    required int amountMinor,
    required String description,
    String? category,
    String? notes,
    DateTime? transactionDate,
  }) {
    final now = DateTime.now();
    return into(transactions).insert(TransactionsCompanion.insert(
      type: type,
      amountMinor: amountMinor,
      description: description,
      category: Value(category),
      notes: Value(notes),
      transactionDate: transactionDate ?? now,
      createdAt: now,
      updatedAt: now,
    ));
  }
}
