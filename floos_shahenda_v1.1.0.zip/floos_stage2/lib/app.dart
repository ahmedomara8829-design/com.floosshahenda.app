import 'package:flutter/material.dart';
import 'core/theme/app_theme.dart';
import 'features/dashboard/dashboard_page.dart';

class FloosShahendaApp extends StatelessWidget {
  const FloosShahendaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'فلوس شاهندة',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      themeMode: ThemeMode.system,
      locale: const Locale('ar'),
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: child ?? const SizedBox.shrink(),
      ),
      home: const DashboardPage(),
    );
  }
}
