import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../data/database/app_database.dart';
import '../../data/database/database_provider.dart';

final totalIncomeProvider = StreamProvider.autoDispose<int>((ref) {
  return ref.watch(databaseProvider).watchTotalIncome();
});

final totalExpenseProvider = StreamProvider.autoDispose<int>((ref) {
  return ref.watch(databaseProvider).watchTotalExpense();
});

final transactionCountProvider = StreamProvider.autoDispose<int>((ref) {
  return ref.watch(databaseProvider).watchTransactionCount();
});

final recentTransactionsProvider = StreamProvider.autoDispose<List<Transaction>>((ref) {
  return ref.watch(databaseProvider).watchRecentTransactions();
});

class DashboardPage extends ConsumerStatefulWidget {
  const DashboardPage({super.key});

  @override
  ConsumerState<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends ConsumerState<DashboardPage> {
  late DateTime _now;
  Timer? _clock;

  @override
  void initState() {
    super.initState();
    _now = DateTime.now();
    _clock = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _now = DateTime.now());
    });
  }

  @override
  void dispose() {
    _clock?.cancel();
    super.dispose();
  }

  String _money(int minor) {
    final value = minor / 100;
    return '${value.toStringAsFixed(2)} ج.م';
  }

  @override
  Widget build(BuildContext context) {
    final income = ref.watch(totalIncomeProvider).value ?? 0;
    final expense = ref.watch(totalExpenseProvider).value ?? 0;
    final count = ref.watch(transactionCountProvider).value ?? 0;
    final recent = ref.watch(recentTransactionsProvider).value ?? const <Transaction>[];
    final balance = income - expense;

    return Scaffold(
      appBar: AppBar(
        title: const Text('💰 فلوس شاهندة'),
        centerTitle: true,
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
          children: [
            Text(DateFormat('dd/MM/yyyy').format(_now), textAlign: TextAlign.center),
            const SizedBox(height: 4),
            Text(DateFormat('hh:mm:ss a', 'ar').format(_now), textAlign: TextAlign.center),
            const SizedBox(height: 18),
            _BalanceCard(value: _money(balance)),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(child: _StatCard(title: 'إجمالي الدخل', value: _money(income), icon: Icons.trending_up, color: Colors.green)),
                const SizedBox(width: 12),
                Expanded(child: _StatCard(title: 'المصروفات', value: _money(expense), icon: Icons.trending_down, color: Colors.red)),
              ],
            ),
            const SizedBox(height: 12),
            _StatCard(title: 'عدد العمليات', value: '$count', icon: Icons.receipt_long, color: Colors.orange),
            const SizedBox(height: 22),
            if (recent.isEmpty)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    children: [
                      Icon(Icons.account_balance_wallet_outlined, size: 52, color: Theme.of(context).colorScheme.primary),
                      const SizedBox(height: 10),
                      Text('ابدأ بإضافة أول عملية', style: Theme.of(context).textTheme.titleMedium),
                      const SizedBox(height: 6),
                      const Text('أضف دخلًا أو مصروفًا، وسيتم تحديث الرصيد والإحصائيات تلقائيًا.'),
                    ],
                  ),
                ),
              )
            else ...[
              Text('آخر العمليات', style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 8),
              ...recent.map((t) => _TransactionTile(transaction: t, money: _money)),
            ],
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showTransactionSheet(context),
        icon: const Icon(Icons.add),
        label: const Text('عملية جديدة'),
      ),
    );
  }

  Future<void> _showTransactionSheet(BuildContext context, {Transaction? transaction}) async {
    final result = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => _TransactionForm(transaction: transaction),
    );
    if (result == true && mounted) setState(() {});
  }
}

class _TransactionForm extends ConsumerStatefulWidget {
  const _TransactionForm({this.transaction});
  final Transaction? transaction;

  @override
  ConsumerState<_TransactionForm> createState() => _TransactionFormState();
}

class _TransactionFormState extends ConsumerState<_TransactionForm> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _amount;
  late final TextEditingController _description;
  late final TextEditingController _category;
  late final TextEditingController _notes;
  late String _type;
  late DateTime _date;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final t = widget.transaction;
    _amount = TextEditingController(text: t == null ? '' : (t.amountMinor / 100).toStringAsFixed(2));
    _description = TextEditingController(text: t?.description ?? '');
    _category = TextEditingController(text: t?.category ?? '');
    _notes = TextEditingController(text: t?.notes ?? '');
    _type = t?.type ?? 'income';
    _date = t?.transactionDate ?? DateTime.now();
  }

  @override
  void dispose() {
    _amount.dispose();
    _description.dispose();
    _category.dispose();
    _notes.dispose();
    super.dispose();
  }

  int? _parseMinor(String text) {
    final normalized = text.trim().replaceAll(',', '.');
    final value = double.tryParse(normalized);
    if (value == null || value <= 0) return null;
    return (value * 100).round();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final amountMinor = _parseMinor(_amount.text);
    if (amountMinor == null) return;
    setState(() => _saving = true);
    final db = ref.read(databaseProvider);
    if (widget.transaction == null) {
      await db.addTransaction(
        type: _type,
        amountMinor: amountMinor,
        description: _description.text.trim(),
        category: _category.text,
        notes: _notes.text,
        transactionDate: _date,
      );
    } else {
      await db.updateTransaction(
        id: widget.transaction!.id,
        type: _type,
        amountMinor: amountMinor,
        description: _description.text.trim(),
        category: _category.text,
        notes: _notes.text,
        transactionDate: _date,
      );
    }
    if (mounted) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    final editing = widget.transaction != null;
    return Padding(
      padding: EdgeInsets.fromLTRB(20, 8, 20, MediaQuery.viewInsetsOf(context).bottom + 20),
      child: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(editing ? 'تعديل العملية' : 'إضافة عملية', style: Theme.of(context).textTheme.headlineSmall),
              const SizedBox(height: 16),
              SegmentedButton<String>(
                segments: const [
                  ButtonSegment(value: 'income', label: Text('➕ دخل'), icon: Icon(Icons.trending_up)),
                  ButtonSegment(value: 'expense', label: Text('➖ مصروف'), icon: Icon(Icons.trending_down)),
                ],
                selected: {_type},
                onSelectionChanged: (v) => setState(() => _type = v.first),
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _amount,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(labelText: 'المبلغ بالجنيه', prefixIcon: Icon(Icons.payments_outlined)),
                validator: (v) => _parseMinor(v ?? '') == null ? 'أدخل مبلغًا صحيحًا أكبر من صفر' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _description,
                decoration: const InputDecoration(labelText: 'البيان', prefixIcon: Icon(Icons.description_outlined)),
                validator: (v) => (v == null || v.trim().isEmpty) ? 'أدخل البيان' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(controller: _category, decoration: const InputDecoration(labelText: 'التصنيف (اختياري)', prefixIcon: Icon(Icons.category_outlined))),
              const SizedBox(height: 12),
              TextFormField(controller: _notes, maxLines: 2, decoration: const InputDecoration(labelText: 'ملاحظات (اختياري)', prefixIcon: Icon(Icons.notes_outlined))),
              const SizedBox(height: 12),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.calendar_month),
                title: const Text('تاريخ العملية'),
                subtitle: Text(DateFormat('dd/MM/yyyy - hh:mm a', 'ar').format(_date)),
                onTap: () async {
                  final picked = await showDatePicker(context: context, initialDate: _date, firstDate: DateTime(2000), lastDate: DateTime(2100));
                  if (picked != null && mounted) {
                    final time = TimeOfDay.fromDateTime(_date);
                    setState(() => _date = DateTime(picked.year, picked.month, picked.day, time.hour, time.minute));
                  }
                },
              ),
              const SizedBox(height: 12),
              FilledButton.icon(onPressed: _saving ? null : _save, icon: const Icon(Icons.save_outlined), label: Text(_saving ? 'جاري الحفظ...' : 'حفظ العملية')),
            ],
          ),
        ),
      ),
    );
  }
}

class _TransactionTile extends StatelessWidget {
  const _TransactionTile({required this.transaction, required this.money});
  final Transaction transaction;
  final String Function(int) money;

  @override
  Widget build(BuildContext context) {
    final income = transaction.type == 'income';
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: (income ? Colors.green : Colors.red).withValues(alpha: .12),
          child: Icon(income ? Icons.add : Icons.remove, color: income ? Colors.green : Colors.red),
        ),
        title: Text(transaction.description),
        subtitle: Text('${DateFormat('dd/MM/yyyy - hh:mm a', 'ar').format(transaction.transactionDate)}${transaction.category == null ? '' : ' • ${transaction.category}'}'),
        trailing: Text('${income ? '+' : '-'}${money(transaction.amountMinor)}', style: TextStyle(fontWeight: FontWeight.bold, color: income ? Colors.green : Colors.red)),
      ),
    );
  }
}

class _BalanceCard extends StatelessWidget {
  const _BalanceCard({required this.value});
  final String value;

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Theme.of(context).colorScheme.primary,
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(children: [
          const Text('الرصيد الحالي', style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 8),
          Text(value, style: const TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.bold)),
        ]),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({required this.title, required this.value, required this.icon, required this.color});
  final String title;
  final String value;
  final IconData icon;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(children: [
          CircleAvatar(backgroundColor: color.withValues(alpha: 0.12), foregroundColor: color, child: Icon(icon)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title), const SizedBox(height: 4), Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17))])),
        ]),
      ),
    );
  }
}
