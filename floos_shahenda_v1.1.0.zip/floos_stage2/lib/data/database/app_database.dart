import 'package:drift/drift.dart';
import 'package:drift_flutter/drift_flutter.dart';

part 'app_database.g.dart';

class Transactions extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get type => text()();
  IntColumn get amountMinor => integer()();
  TextColumn get description => text().withLength(min: 1, max: 500)();
  TextColumn get category => text().nullable()();
  TextColumn get notes => text().nullable()();
  DateTimeColumn get transactionDate => dateTime()();
  DateTimeColumn get createdAt => dateTime()();
  DateTimeColumn get updatedAt => dateTime()();
  TextColumn get importHash => text().nullable().unique()();

}

@DriftDatabase(tables: [Transactions])
class AppDatabase extends _$AppDatabase {
  AppDatabase() : super(driftDatabase(name: 'floos_shahenda'));

  @override
  int get schemaVersion => 1;

  Stream<List<Transaction>> watchAllTransactions() {
    return (select(transactions)
          ..orderBy([(t) => OrderingTerm.desc(t.transactionDate), (t) => OrderingTerm.desc(t.id)]))
        .watch();
  }

  Stream<List<Transaction>> watchRecentTransactions({int limit = 8}) {
    final query = select(transactions)
      ..orderBy([(t) => OrderingTerm.desc(t.transactionDate), (t) => OrderingTerm.desc(t.id)])
      ..limit(limit);
    return query.watch();
  }

  Stream<int> watchTotalIncome() {
    final query = selectOnly(transactions)
      ..addColumns([transactions.amountMinor.sum()])
      ..where(transactions.type.equals('income'));
    return query.watchSingle().map((row) => row.read(transactions.amountMinor.sum()) ?? 0);
  }

  Stream<int> watchTotalExpense() {
    final query = selectOnly(transactions)
      ..addColumns([transactions.amountMinor.sum()])
      ..where(transactions.type.equals('expense'));
    return query.watchSingle().map((row) => row.read(transactions.amountMinor.sum()) ?? 0);
  }

  Stream<int> watchTransactionCount() {
    final query = selectOnly(transactions)..addColumns([transactions.id.count()]);
    return query.watchSingle().map((row) => row.read(transactions.id.count()) ?? 0);
  }

  Future<int> addTransaction({
    required String type,
    required int amountMinor,
    required String description,
    String? category,
    String? notes,
    DateTime? transactionDate,
  }) {
    final now = DateTime.now();
    return into(transactions).insert(TransactionsCompanion.insert(
      type: type,
      amountMinor: amountMinor,
      description: description,
      category: Value(category?.trim().isEmpty == true ? null : category?.trim()),
      notes: Value(notes?.trim().isEmpty == true ? null : notes?.trim()),
      transactionDate: transactionDate ?? now,
      createdAt: now,
      updatedAt: now,
    ));
  }

  Future<bool> updateTransaction({
    required int id,
    required String type,
    required int amountMinor,
    required String description,
    String? category,
    String? notes,
    required DateTime transactionDate,
  }) {
    return (update(transactions)..where((t) => t.id.equals(id))).write(
      TransactionsCompanion(
        type: Value(type),
        amountMinor: Value(amountMinor),
        description: Value(description),
        category: Value(category?.trim().isEmpty == true ? null : category?.trim()),
        notes: Value(notes?.trim().isEmpty == true ? null : notes?.trim()),
        transactionDate: Value(transactionDate),
        updatedAt: Value(DateTime.now()),
      ),
    ).then((count) => count == 1);
  }

  Future<int> deleteTransaction(int id) {
    return (delete(transactions)..where((t) => t.id.equals(id))).go();
  }
}
