import 'dart:ui' show TextDirection;
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const FloosShahendaApp());
}

class MoneyTransaction {
  const MoneyTransaction({
    required this.id,
    required this.type,
    required this.amount,
    required this.description,
    required this.date,
    this.category = '',
    this.notes = '',
  });

  final String id;
  final String type;
  final double amount;
  final String description;
  final DateTime date;
  final String category;
  final String notes;

  bool get isIncome => type == 'income';

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type,
        'amount': amount,
        'description': description,
        'date': date.toIso8601String(),
        'category': category,
        'notes': notes,
      };

  factory MoneyTransaction.fromJson(Map<String, dynamic> json) {
    return MoneyTransaction(
      id: json['id']?.toString() ?? DateTime.now().microsecondsSinceEpoch.toString(),
      type: json['type'] == 'expense' ? 'expense' : 'income',
      amount: (json['amount'] as num?)?.toDouble() ?? 0,
      description: json['description']?.toString() ?? '',
      date: DateTime.tryParse(json['date']?.toString() ?? '') ?? DateTime.now(),
      category: json['category']?.toString() ?? '',
      notes: json['notes']?.toString() ?? '',
    );
  }
}

class FloosShahendaApp extends StatelessWidget {
  const FloosShahendaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'فلوس شاهندة',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.indigo,
        scaffoldBackgroundColor: const Color(0xFFF5F7FB),
        inputDecorationTheme: const InputDecorationTheme(
          border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(14))),
        ),
      ),
      home: const DashboardPage(),
    );
  }
}

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  static const _storageKey = 'floos_shahenda_transactions_v2';
  final DateFormat _dateFormat = DateFormat('dd/MM/yyyy');
  final DateFormat _timeFormat = DateFormat('hh:mm:ss a', 'ar');

  List<MoneyTransaction> _items = <MoneyTransaction>[];
  DateTime _now = DateTime.now();
  bool _loading = true;

  double get income => _items.where((e) => e.isIncome).fold(0, (sum, e) => sum + e.amount);
  double get expense => _items.where((e) => !e.isIncome).fold(0, (sum, e) => sum + e.amount);
  double get balance => income - expense;

  @override
  void initState() {
    super.initState();
    _loadData();
    _startClock();
  }

  void _startClock() {
    Future<void>.delayed(const Duration(seconds: 1), () {
      if (!mounted) return;
      setState(() => _now = DateTime.now());
      _startClock();
    });
  }

  Future<void> _loadData() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_storageKey);
      if (raw != null && raw.isNotEmpty) {
        final decoded = jsonDecode(raw);
        if (decoded is List) {
          _items = decoded
              .whereType<Map>()
              .map((e) => MoneyTransaction.fromJson(Map<String, dynamic>.from(e)))
              .toList();
          _items.sort((a, b) => b.date.compareTo(a.date));
        }
      }
    } catch (_) {
      _items = <MoneyTransaction>[];
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _saveData() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = jsonEncode(_items.map((e) => e.toJson()).toList());
    await prefs.setString(_storageKey, raw);
  }

  String _money(double value) => '${value.toStringAsFixed(2)} ج.م';

  Future<void> _addTransaction() async {
    final result = await showModalBottomSheet<MoneyTransaction>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => const TransactionForm(),
    );
    if (result == null) return;
    setState(() {
      _items.insert(0, result);
      _items.sort((a, b) => b.date.compareTo(a.date));
    });
    await _saveData();
  }

  Future<void> _deleteTransaction(MoneyTransaction item) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('حذف العملية'),
        content: Text('هل تريد حذف «${item.description}»؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حذف')),
        ],
      ),
    );
    if (ok != true) return;
    setState(() => _items.removeWhere((e) => e.id == item.id));
    await _saveData();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('💰 فلوس شاهندة', style: TextStyle(fontWeight: FontWeight.bold)),
          centerTitle: true,
          actions: [
            IconButton(
              tooltip: 'مسح جميع البيانات',
              icon: const Icon(Icons.delete_sweep_outlined),
              onPressed: _items.isEmpty ? null : _clearAll,
            ),
          ],
        ),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : RefreshIndicator(
                onRefresh: _loadData,
                child: ListView(
                  physics: const AlwaysScrollableScrollPhysics(),
                  padding: const EdgeInsets.fromLTRB(14, 8, 14, 100),
                  children: [
                    Text(_dateFormat.format(_now), textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w600)),
                    const SizedBox(height: 2),
                    Text(_timeFormat.format(_now), textAlign: TextAlign.center),
                    const SizedBox(height: 14),
                    _BalanceCard(balance: balance, money: _money),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(child: _StatCard(title: 'إجمالي الدخل', value: _money(income), icon: Icons.arrow_downward_rounded, color: Colors.green)),
                        const SizedBox(width: 10),
                        Expanded(child: _StatCard(title: 'إجمالي المصروفات', value: _money(expense), icon: Icons.arrow_upward_rounded, color: Colors.red)),
                      ],
                    ),
                    const SizedBox(height: 10),
                    _StatCard(title: 'عدد العمليات', value: '${_items.length}', icon: Icons.receipt_long_rounded, color: Colors.orange),
                    const SizedBox(height: 18),
                    Text('آخر العمليات', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    if (_items.isEmpty)
                      const Card(
                        child: Padding(
                          padding: EdgeInsets.all(26),
                          child: Column(
                            children: [
                              Icon(Icons.account_balance_wallet_outlined, size: 54),
                              SizedBox(height: 10),
                              Text('لا توجد عمليات حتى الآن', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                              SizedBox(height: 5),
                              Text('اضغط «إضافة عملية» لتسجيل دخل أو مصروف.'),
                            ],
                          ),
                        ),
                      )
                    else
                      ..._items.map((item) => _TransactionTile(item: item, money: _money, onDelete: () => _deleteTransaction(item))),
                  ],
                ),
              ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: _addTransaction,
          icon: const Icon(Icons.add),
          label: const Text('إضافة عملية'),
        ),
      ),
    );
  }

  Future<void> _clearAll() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('مسح البيانات'),
        content: const Text('سيتم حذف كل الدخل والمصروفات من هذا الهاتف. هل أنت متأكد؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('مسح الكل')),
        ],
      ),
    );
    if (ok != true) return;
    setState(() => _items.clear());
    await _saveData();
  }
}

class TransactionForm extends StatefulWidget {
  const TransactionForm({super.key});

  @override
  State<TransactionForm> createState() => _TransactionFormState();
}

class _TransactionFormState extends State<TransactionForm> {
  final _formKey = GlobalKey<FormState>();
  final _amount = TextEditingController();
  final _description = TextEditingController();
  final _category = TextEditingController();
  final _notes = TextEditingController();
  String _type = 'income';
  DateTime _date = DateTime.now();
  bool _saving = false;

  @override
  void dispose() {
    _amount.dispose();
    _description.dispose();
    _category.dispose();
    _notes.dispose();
    super.dispose();
  }

  double? _parseAmount(String text) {
    final normalized = text.trim().replaceAll(',', '.');
    final value = double.tryParse(normalized);
    if (value == null || value <= 0) return null;
    return value;
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final amount = _parseAmount(_amount.text);
    if (amount == null) return;
    setState(() => _saving = true);
    final item = MoneyTransaction(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      type: _type,
      amount: amount,
      description: _description.text.trim(),
      date: _date,
      category: _category.text.trim(),
      notes: _notes.text.trim(),
    );
    if (mounted) Navigator.pop(context, item);
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.viewInsetsOf(context).bottom;
    return Padding(
      padding: EdgeInsets.fromLTRB(18, 10, 18, bottom + 18),
      child: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('إضافة عملية جديدة', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
              const SizedBox(height: 16),
              SegmentedButton<String>(
                segments: const [
                  ButtonSegment(value: 'income', label: Text('دخل'), icon: Icon(Icons.add_circle_outline)),
                  ButtonSegment(value: 'expense', label: Text('مصروف'), icon: Icon(Icons.remove_circle_outline)),
                ],
                selected: {_type},
                onSelectionChanged: (value) => setState(() => _type = value.first),
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _amount,
                autofocus: true,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(labelText: 'المبلغ بالجنيه', prefixIcon: Icon(Icons.payments_outlined)),
                validator: (value) => _parseAmount(value ?? '') == null ? 'أدخل مبلغًا صحيحًا' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _description,
                decoration: const InputDecoration(labelText: 'البيان', prefixIcon: Icon(Icons.description_outlined)),
                validator: (value) => value == null || value.trim().isEmpty ? 'اكتب البيان' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(controller: _category, decoration: const InputDecoration(labelText: 'التصنيف (اختياري)', prefixIcon: Icon(Icons.category_outlined))),
              const SizedBox(height: 12),
              TextFormField(controller: _notes, maxLines: 2, decoration: const InputDecoration(labelText: 'ملاحظات (اختياري)', prefixIcon: Icon(Icons.notes_outlined))),
              const SizedBox(height: 8),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.calendar_month_outlined),
                title: const Text('تاريخ العملية'),
                subtitle: Text(DateFormat('dd/MM/yyyy - hh:mm a', 'ar').format(_date)),
                onTap: () async {
                  final picked = await showDatePicker(
                    context: context,
                    initialDate: _date,
                    firstDate: DateTime(2000),
                    lastDate: DateTime(2100),
                  );
                  if (picked != null && mounted) {
                    setState(() => _date = DateTime(picked.year, picked.month, picked.day, _date.hour, _date.minute));
                  }
                },
              ),
              const SizedBox(height: 10),
              FilledButton.icon(
                onPressed: _saving ? null : _save,
                icon: const Icon(Icons.save_outlined),
                label: Text(_saving ? 'جاري الحفظ...' : 'حفظ العملية'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _BalanceCard extends StatelessWidget {
  const _BalanceCard({required this.balance, required this.money});
  final double balance;
  final String Function(double) money;

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          children: [
            const Text('الرصيد الحالي', style: TextStyle(fontSize: 16)),
            const SizedBox(height: 6),
            Text(money(balance), style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({required this.title, required this.value, required this.icon, required this.color});
  final String title;
  final String value;
  final IconData icon;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(15),
        child: Row(
          children: [
            CircleAvatar(backgroundColor: color.withOpacity(.12), foregroundColor: color, child: Icon(icon)),
            const SizedBox(width: 10),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title), const SizedBox(height: 3), Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16))])),
          ],
        ),
      ),
    );
  }
}

class _TransactionTile extends StatelessWidget {
  const _TransactionTile({required this.item, required this.money, required this.onDelete});
  final MoneyTransaction item;
  final String Function(double) money;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    final color = item.isIncome ? Colors.green : Colors.red;
    return Card(
      elevation: 0,
      child: ListTile(
        leading: CircleAvatar(backgroundColor: color.withOpacity(.12), foregroundColor: color, child: Icon(item.isIncome ? Icons.add : Icons.remove)),
        title: Text(item.description, maxLines: 1, overflow: TextOverflow.ellipsis),
        subtitle: Text('${DateFormat('dd/MM/yyyy - hh:mm a', 'ar').format(item.date)}${item.category.isEmpty ? '' : ' • ${item.category}'}'),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(money(item.amount), style: TextStyle(fontWeight: FontWeight.bold, color: color)),
            IconButton(onPressed: onDelete, icon: const Icon(Icons.delete_outline)),
          ],
        ),
      ),
    );
  }
}
